import pytest
from shopping_cart import item_total, cart_discount, shipping_fee

#Example test cases:
def test_food_item():
    assert item_total("food", 100, 2) == 210

def test_free_shipping():
    assert shipping_fee(1000, False, False) == 0

#Write the rest of the test cases so that the code is 90- 100% covered.


# ---------------------------------------------------------------- item_total
def test_item_total_electronics_gst_18():
    assert item_total("electronics", 100, 1) == 118


def test_item_total_clothing_gst_12():
    assert item_total("clothing", 200, 1) == 224


def test_item_total_unknown_category_raises():
    with pytest.raises(ValueError, match="unknown category"):
        item_total("toys", 100, 1)


def test_item_total_negative_price_raises():
    with pytest.raises(ValueError, match="invalid price or quantity"):
        item_total("food", -1, 1)


def test_item_total_zero_quantity_raises():
    with pytest.raises(ValueError, match="invalid price or quantity"):
        item_total("food", 100, 0)


def test_item_total_negative_quantity_raises():
    with pytest.raises(ValueError, match="invalid price or quantity"):
        item_total("food", 100, -3)


def test_item_total_zero_price_is_allowed():
    assert item_total("food", 0, 5) == 0


def test_item_total_bulk_discount_at_threshold():
    # qty == 10 -> 10% off: 1000 - 100 = 900, +5% GST = 945
    assert item_total("food", 100, 10) == 945


def test_item_total_no_bulk_discount_just_below_threshold():
    # qty == 9 -> no discount: 900 + 5% GST (45) = 945
    assert item_total("food", 100, 9) == 945


def test_item_total_bulk_discount_above_threshold():
    # 20 * 50 = 1000 -> 900 after discount -> +18% = 1062
    assert item_total("electronics", 50, 20) == 1062


# ------------------------------------------------------------- cart_discount
def test_cart_discount_high_value_500():
    assert cart_discount(5000, False, None) == 500


def test_cart_discount_mid_value_200():
    assert cart_discount(2000, False, None) == 200


def test_cart_discount_low_value_zero():
    assert cart_discount(1999, False, None) == 0


def test_cart_discount_just_below_5000_uses_mid_tier():
    assert cart_discount(4999, False, None) == 200


def test_cart_discount_prime_adds_100():
    assert cart_discount(100, True, None) == 100


def test_cart_discount_prime_stacks_with_tier():
    assert cart_discount(5000, True, None) == 600


def test_cart_discount_flat10_applies_when_value_at_least_1000():
    # tier 0 (value < 2000) + 10% of 1000
    assert cart_discount(1000, False, "FLAT10") == 100


def test_cart_discount_flat10_not_applied_below_1000():
    assert cart_discount(999, False, "FLAT10") == 0


def test_cart_discount_wrong_coupon_ignored():
    assert cart_discount(3000, False, "SAVE5") == 200


def test_cart_discount_everything_combined():
    # 500 (tier) + 100 (prime) + 600 (10% of 6000)
    assert cart_discount(6000, True, "FLAT10") == 1200


# ------------------------------------------------------------- shipping_fee
def test_shipping_prime_free():
    assert shipping_fee(100, True, False) == 0


def test_shipping_threshold_500_is_free():
    assert shipping_fee(500, False, False) == 0


def test_shipping_below_500_charged_40():
    assert shipping_fee(499, False, False) == 40


def test_shipping_express_non_prime_free_cart():
    assert shipping_fee(1000, False, True) == 100


def test_shipping_express_non_prime_small_cart():
    assert shipping_fee(100, False, True) == 140


def test_shipping_express_prime_gets_50_off_express():
    assert shipping_fee(100, True, True) == 50
