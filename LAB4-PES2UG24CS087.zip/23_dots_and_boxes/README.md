# Scenario 23 - Dots and Boxes

## Overview

Dots and Boxes is a turn-based grid game. Players draw one line at a time between adjacent dots. Completing the fourth side of a box claims that box, earns a point, and gives the same player another turn.

The starter project is deliberately split into separate modules for game flow, board state, and rule validation. Read the existing implementation carefully before changing it.

## How to run

From this folder:

```text
python main.py
```

Enter moves in the form:

```text
H row column
```

or

```text
V row column
```

Rows and columns start at zero.

## Task 1 — Reproduce and investigate the bug

Run several games and deliberately create situations where a move completes one or more boxes.

Compare the score and turn behaviour before and after box completion. Identify the incorrect behaviour, trace it through the board and game-state logic, and fix it without replacing the modular structure.

Your before-change video should capture the broken behaviour clearly.

## Task 2 — Add a meaningful feature

Add a substantial gameplay feature that requires changes across more than one module.

The feature should make the game more complete rather than simply changing text or appearance. It should interact correctly with the existing board state and turn/score system.

## Task 3 — Validation and robustness

Strengthen input and game-state handling.

The program should safely handle malformed commands, invalid coordinates, repeated lines, and moves made after the board is already complete. Invalid input must not corrupt the board or score.

## Task 4 — Testing and quality

Create or expand automated tests covering the important game rules.

Include tests for at least:
- a valid horizontal move
- a valid vertical move
- an invalid/repeated move
- completion of a box
- the end-of-game condition

Document the changes you made and any design decisions that were important to the solution.

## Implementation notes

- `Board.add_line` validates moves, rejects occupied or out-of-range lines,
  and returns the number of boxes completed by that move. This keeps box
  detection in the board module and score/turn updates in the game module.
- `rules.py` contains legal-move enumeration and the computer opponent's
  move-selection heuristic; it uses the same board and turn rules as a second
  human player.
- `test_game.py` uses Python's built-in `unittest` framework and covers
  horizontal and vertical moves, invalid/repeated moves, box scoring and
  retained turns, completed-board rejection, and the computer's box-taking
  move.
- Board sizes can be selected when constructing `DotsAndBoxes`, for example
  `DotsAndBoxes(rows=3, cols=4)`. The command-line game continues to use the
  default 2-by-2 board.
- The computer uses a simple local heuristic; it is not intended to play
  perfectly.

## Validation results

- Three complete scripted 2-by-2 games against the committed starter code
  finished with all four boxes scored (2–2, 4–0, and 0–4). The described
  box-scoring bug was not reproducible in that version. The score update was
  consolidated around the board's returned box count to keep box detection
  and turn/score handling consistent.
- The updated suite passes with `python -m unittest -v` (7 tests).
- A scripted 2-by-2 game against the computer completed with all boxes scored.

Because the starter version already behaved correctly in the baseline run, a
before-change video showing the claimed broken behavior cannot be made from
this checkout without inventing or altering the behavior.

## Constraints

- Keep the project modular.
- Do not replace the game with an unrelated implementation.
- Preserve the existing gameplay.
- Avoid putting all new logic into `main.py`.
- Keep third-party dependencies out unless there is a clear need for them.

## Submission Checklist

Submission is only the following three things:

- [ ] A 10-second video of gameplay **before** your changes, showing the bug/broken behavior
- [ ] A 10-second video of gameplay **after** your changes, showing the bug fixed and the new features working
- [ ] The Chat/LLM used page link, with the complete chat history
