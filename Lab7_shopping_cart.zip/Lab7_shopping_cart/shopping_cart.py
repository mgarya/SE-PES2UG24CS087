import re

ZONES = {"1": "North", "2": "North", "3": "West", "4": "West",
         "5": "South", "6": "South", "7": "East", "8": "East"}

_PROMO_RE = re.compile(r"[A-Z0-9]*OFF([0-9]{1,3})", re.ASCII)
_PIN_RE = re.compile(r"[0-9]{6}", re.ASCII)
_DIGITS_RE = re.compile(r"[0-9]+", re.ASCII)


def _parse_non_negative_int(text, what):
    """Parse an ASCII-digit string into an int, or raise ValueError."""
    text = text.strip()
    if not _DIGITS_RE.fullmatch(text):
        raise ValueError(f"invalid {what}: {text!r}")
    return int(text)


def cart_total(cart):
    """Total of a 'name:pricexqty,name:pricexqty' cart string.

    Raises ValueError for anything that is not a well-formed cart
    (None / non-string, empty string, missing ':' or 'x', non-numeric
    or negative price/quantity).
    """
    if not isinstance(cart, str) or not cart.strip():
        raise ValueError("cart must be a non-empty string")
    total = 0
    for item in cart.split(','):
        parts = item.split(':')
        if len(parts) != 2 or not parts[0].strip():
            raise ValueError(f"invalid cart item: {item!r}")
        rest = parts[1].split('x')
        if len(rest) != 2:
            raise ValueError(f"invalid cart item: {item!r}")
        price = _parse_non_negative_int(rest[0], "price")
        qty = _parse_non_negative_int(rest[1], "quantity")
        total += price * qty
    return total


def promo_percent(code):
    """Discount percent from a promo code such as 'OFF20' (case-insensitive).

    Raises ValueError if the code is not a string, has no 'OFF<digits>'
    ending, or the percent is above 100.
    """
    if not isinstance(code, str):
        raise ValueError("promo code must be a string")
    match = _PROMO_RE.fullmatch(code.strip().upper())
    if match is None:
        raise ValueError(f"invalid promo code: {code!r}")
    percent = int(match.group(1))
    if percent > 100:
        raise ValueError("discount percent cannot exceed 100")
    return percent


def delivery_zone(pincode):
    """Delivery zone for a 6 digit pincode.

    Raises ValueError if the pincode is not exactly 6 ASCII digits or its
    first digit does not map to a zone.
    """
    if not isinstance(pincode, str) or not _PIN_RE.fullmatch(pincode):
        raise ValueError(f"invalid pincode: {pincode!r}")
    if pincode[0] not in ZONES:
        raise ValueError(f"no delivery zone for pincode: {pincode!r}")
    return ZONES[pincode[0]]


def main():
    print("==== Running cart_total ====")
    user_input = input("Enter cart as name:pricexqty CSV (e.g. pen:10x2,book:250x1): ")
    try:
        print("Cart Total:", cart_total(user_input))
    except ValueError as e:
        print("Error:", e)

    print("\n==== Running promo_percent ====")
    user_input = input("Enter a promo code (e.g. OFF20): ")
    try:
        print("Discount Percent:", promo_percent(user_input))
    except ValueError as e:
        print("Error:", e)

    print("\n==== Running delivery_zone ====")
    user_input = input("Enter a 6 digit pincode (e.g. 560085): ")
    try:
        print("Delivery Zone:", delivery_zone(user_input))
    except ValueError as e:
        print("Error:", e)

if __name__ == "__main__":
    main()
