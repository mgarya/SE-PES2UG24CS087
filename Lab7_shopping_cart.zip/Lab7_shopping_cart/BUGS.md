# Lab 7 – Fuzz Testing: Bugs Found and Fixed

Hypothesis fuzzing (`st.text() | st.none()`) against the original `shopping_cart.py`
exposes unhandled exceptions in all three functions.

| Function | Failing input | Original exception | Root cause |
|----------|---------------|--------------------|------------|
| `cart_total` | `None` | `AttributeError` | `.split` called on a non-string |
| `promo_percent` | `None` | `AttributeError` | `.upper` called on a non-string |
| `promo_percent` | `""`, `"SAVE"` | `IndexError` | `split('OFF')[1]` when code has no `OFF` |
| `promo_percent` | `"OFF1OFF2"` | returned `1` silently | extra `OFF` segments ignored; no validation |
| `promo_percent` | `"OFF999"` | returned `999` | no range check (percent > 100) |
| `delivery_zone` | `None` | `TypeError` | indexing a non-string |
| `delivery_zone` | `""` | `IndexError` | `pincode[0]` on an empty string |
| `delivery_zone` | `"0..."`, `"9..."`, `"abc"` | `KeyError` | first character not a key in `ZONES` |
| `delivery_zone` | `"5"` | returned `"South"` | length/digits never checked (not a 6 digit pincode) |
| `cart_total` | `"a:-5x2"` | returned `-10` | negative price/quantity accepted |

## Fix

Every function now validates its input up front and raises a clear `ValueError`
for anything malformed, so callers have one exception type to handle:

- `cart_total`: input must be a non-empty string; each item must be exactly
  `name:pricexqty` with a non-empty name and ASCII-digit price and quantity.
- `promo_percent`: input must be a string matching `<letters/digits>OFF<1-3 digits>`
  (case-insensitive) and the percent must be 0-100.
- `delivery_zone`: input must be exactly 6 ASCII digits and the first digit must
  be a key of `ZONES` (1-8).
- `main()` catches `ValueError` and prints an error message instead of a traceback.

## Fuzz tests

`test_shopping_cart.py` contains the three required `*_no_crash` tests (ValueError
is the only allowed exception; valid results are also sanity-checked) plus three
structured property tests that generate valid inputs and check exact results.

Run with: `pip install pytest hypothesis && pytest -v`
