from hypothesis import given, strategies as st
from shopping_cart import cart_total, promo_percent, delivery_zone, ZONES

# Fuzz contract: for ANY input (including None) a function either returns a
# valid result or raises ValueError (its documented rejection of bad input).
# Any other exception (IndexError, KeyError, AttributeError, TypeError, ...)
# is a crash and fails the test.


@given(st.text() | st.none())
def test_cart_total_no_crash(s):
    try:
        result = cart_total(s)
    except ValueError:
        return
    assert isinstance(result, int) and result >= 0


@given(st.text() | st.none())
def test_promo_percent_no_crash(s):
    try:
        result = promo_percent(s)
    except ValueError:
        return
    assert isinstance(result, int) and 0 <= result <= 100


@given(st.text() | st.none())
def test_delivery_zone_no_crash(s):
    try:
        result = delivery_zone(s)
    except ValueError:
        return
    assert result in set(ZONES.values())


# ---- Extra: structured fuzzing so valid inputs are exercised often ----------

@given(st.lists(st.tuples(st.text(alphabet="abcdefgh", min_size=1),
                          st.integers(0, 10**6),
                          st.integers(0, 10**3)), min_size=1))
def test_cart_total_valid_carts(items):
    cart = ",".join(f"{n}:{p}x{q}" for n, p, q in items)
    assert cart_total(cart) == sum(p * q for _, p, q in items)


@given(st.integers(0, 100), st.sampled_from(["OFF", "off", "Off"]))
def test_promo_percent_valid_codes(pct, off):
    assert promo_percent(f"{off}{pct}") == pct


@given(st.sampled_from("12345678"), st.text(alphabet="0123456789", min_size=5, max_size=5))
def test_delivery_zone_valid_pincodes(first, rest):
    assert delivery_zone(first + rest) == ZONES[first]
